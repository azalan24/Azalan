const featuredSection = document.querySelector('.featured-items');

window.addEventListener('scroll', () => {
  if (window.scrollY > 100) { // Change 100 to your desired threshold
    featuredSection.classList.add('rise');
  } else {
    featuredSection.classList.remove('rise');
  }
});